document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
    const captchaInput = document.getElementById("captcha");
    const mobileNumberInput = document.getElementById("mobile-number");
    const refreshBtn = document.getElementById("refresh-btn");
    const captchaImage = document.getElementById("captchaImage");

    
    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent form from submitting

        // Check if the captcha field is empty
        if (!captchaInput.value) {
            alert("Please fill captcha");
            return; // Stop the function execution here
        }

        // Check if the mobile number field is empty
        if (!mobileNumberInput.value) {
            alert("Please fill your mobile.");
            return; // Stop the function execution here
        }
         
        // Check if the mobile number field is wrong
        if (mobileNumberInput.value !== "8595269215") {
            alert("mobile no. not registered With this passid .\nPlease try again");
            return; // Stop the function execution here
        }

        // Check if the entered captcha is correct
        if (captchaInput.value !== "X0Db6Z") {
            alert("Captcha validation failed. Please try again");
            return; // Stop the function execution here
        }

        // If all checks pass, submit the form (or do whatever is needed next)
        // form.submit(); // Uncomment this line if you want to submit the form after validation
        console.log("Form submitted"); // Placeholder action

        window.location.href = "pass.html";
    });

});